/**
 * Soft section blends and page fades.
 *
 * Set SOFT_TRANSITIONS_ENABLED to false to restore the original look: the
 * homepage goes back to its original dividers and gradient strips, and pages
 * switch without a fade. Nothing else reads this flag.
 */
export const SOFT_TRANSITIONS_ENABLED = true;

/**
 * Development-only preview: add ?transitions=off (or =on) to the URL to compare
 * without editing the flag. Production builds ignore the query string.
 */
function devOverride(): boolean | null {
  if (!import.meta.env.DEV || typeof window === 'undefined') return null;
  const value = new URLSearchParams(window.location.search).get('transitions');
  if (value === 'off') return false;
  if (value === 'on') return true;
  return null;
}

export const softTransitionsOn: boolean = devOverride() ?? SOFT_TRANSITIONS_ENABLED;
