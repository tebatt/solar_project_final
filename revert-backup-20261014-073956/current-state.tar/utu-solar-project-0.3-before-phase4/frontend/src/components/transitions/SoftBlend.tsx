import type { CSSProperties } from 'react';
import '../../styles/soft-transitions.css';

type Rgb = `${number} ${number} ${number}`;

/**
 * A zero-height blend on the boundary between a dark and a light section.
 * `light` is the light section's background, `ink` the dark section's colour
 * at the boundary; both as space-separated RGB channels.
 */
export function SoftBlend({
  direction,
  light,
  ink,
}: {
  direction: 'to-light' | 'to-dark';
  light: Rgb;
  ink: Rgb;
}) {
  const style = { '--blend-light': light, '--blend-ink': ink } as CSSProperties;
  return (
    <div
      aria-hidden="true"
      data-testid="soft-blend"
      data-direction={direction}
      className={`soft-blend soft-blend--${direction}`}
      style={style}
    >
      <span />
    </div>
  );
}
