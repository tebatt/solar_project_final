import { motion, useReducedMotion } from 'framer-motion';
import type { ReactNode } from 'react';
import { softTransitionsOn } from '../../theme/softTransitions';

/**
 * Fades a page in when the route changes (enter only, so the new page is never
 * held back by an exit animation). Under reduced motion the page appears
 * without animating; with the flag off it renders exactly as it always did.
 */
export function PageTransition({ routeKey, children }: { routeKey: string; children: ReactNode }) {
  // framer-motion's hook reads the setting on first render, so the page does
  // not remount when the preference is picked up.
  const prefersReduced = useReducedMotion();
  if (!softTransitionsOn) return <>{children}</>;

  return (
    <motion.div
      key={routeKey}
      initial={prefersReduced ? false : { opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: [0.25, 0.1, 0.25, 1] }}
    >
      {children}
    </motion.div>
  );
}
